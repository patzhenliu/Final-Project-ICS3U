import Game
# main game have fun

# create game and run it:
my_game = Game.Game()
my_game.run()
